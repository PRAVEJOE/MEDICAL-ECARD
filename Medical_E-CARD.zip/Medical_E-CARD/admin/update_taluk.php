<?php
include '../connection.php';
$v=$_GET['v'];
$id=$_GET['id'];
$up_taluk=mysql_query("update tal_info set tal_nme='$v' where id='$id'");
if($up_taluk>0)
{
    echo $v;
}
?>
<?php
include '../connection.php';
ob_start();
session_start();
if(isset($_SESSION['aprm']))
{
    $sel_stf=mysql_query("select * from staff_data where em='".$_SESSION['aprm']."'");
    $r_stf=mysql_fetch_row($sel_stf);
    $h_id=$r_stf[1];
    $sel_hos=mysql_query("select * from org_data,abt_hospital where abt_hospital.h_id=org_data.unme and org_data.unme='$h_id'");
    $r_hos=mysql_fetch_row($sel_hos);
}
else
{
    header("location:../index.php");
}
if(isset($_POST['add_mdc']))
{
    $mdcn=$_POST['mdcn'];
    $mds=$_POST['mds'];
    $bar1=$_POST['bar1'];
    $en1=$_POST['en1'];
    $ins_admit_md=mysql_query("insert into admit_medicine values('','".$_GET['aid']."','$en1','$bar1','".date('Y-m-d')."','$mdcn','$mds','".$_SESSION['aprm']."')");
    if($ins_admit_md>0)
    {
        header("location:patient.php?t=1&aid=".$_GET['aid']);
    }
}
if(isset($_POST['add_rpt']))
{
    $rtst=$_POST['rtst'];
    $up=$_FILES['up']['name'];    
    $rtyp=$_POST['rtyp'];
    $bar1=$_POST['bar1'];
    $en1=$_POST['en1'];
    $sel_count=mysql_query("select * from admit_report where f_typ='$rtyp'");
    $r_count=  mysql_num_rows($sel_count);
    $count=$r_count+1;
    $ext1=strrpos($up,".");
    $ext=substr($up,$ext1);
    $nfn="$count$ext";
    $ins_rpt=mysql_query("insert into admit_report values('','".$_GET['aid']."','$en1','$bar1','".date('Y-m-d')."','$rtst','$nfn','$rtyp','".$_SESSION['aprm']."')");
    if($ins_rpt>0)
    {
        if(move_uploaded_file($_FILES['up']['tmp_name'], getcwd()."\\$rtyp\\$nfn"))
        {
            header("location:patient.php?t=2&aid=".$_GET['aid']);
        }
    }
}
if(isset($_POST['add_rvw']))
{
    $ddes=$_POST['ddsc'];
    $bar1=$_POST['bar1'];
    $en1=$_POST['en1'];
    $ins_admit_doc_des=mysql_query("insert into admit_doc_des values('','".$_GET['aid']."','$en1','$bar1','".date('Y-m-d')."','$ddes','".$_SESSION['aprm']."')");
    if($ins_admit_doc_des>0)
    {
        header("location:patient.php?t=3&aid=".$_GET['aid']);
    }
}
if(isset($_GET['dis']))
{
    $dt=date('Y-m-d');
    $up=mysql_query("update new_patient set dt2='$dt' where id='".$_GET['eid']."'");
    if($up>0)
    {
        $up1=mysql_query("update admit_entry set st=1 where id='".$_GET['aid']."'");
        if($up1>0)
        {
         header("location:patient.php");   
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from jollythemes.com/html/jollymedic/index1.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 05 Nov 2016 11:13:49 GMT -->
<head>
  
  <meta http-equiv="content-type" content="text/html; charset=UTF-8"> 

  <title>Medical E CARD</title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">

  <!-- Bootstrap Styles -->
  <link href="../web_style/css/bootstrap.css" rel="stylesheet">
  <!-- Awesome Icons -->
  <link rel="stylesheet" href="../web_style/css/font-awesome.css">
  <!-- Carousel -->
  <link href="../web_style/css/owl-carousel.css" rel="stylesheet">
  <!-- SLIDER REVOLUTION 4.x CSS SETTINGS -->
  <link rel="stylesheet" type="text/css" href="../web_style/rs-plugin/css/settings.css" media="screen" />
  <!-- Styles -->
  <link href="../web_style/style.css" rel="stylesheet">
  <!-- Google Fonts -->
  <link href='http://fonts.googleapis.com/css?family=Lato:400,400italic,700,700italic,900,300' rel='stylesheet' type='text/css'>
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,500italic,700,700italic,900' rel='stylesheet' type='text/css'>
  
  <!-- Support for HTML5 -->
  <!--[if lt IE 9]>
    <script src="../web_style/js/html5shiv.js"></script>
  <![endif]-->

  <!-- Enable media queries on older bgeneral_rowsers -->
  <!--[if lt IE 9]>
    <script src="../web_style/js/respond.min.js"></script>  <![endif]-->

</head>
<body>

<div class="animationload">
<div class="loader">Loading...</div>
</div>

    <div class="topbar">
    	<div class="container">
        	<div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="callout">
                        <span class="topbar-email"><i class="fa fa-globe"></i> <a href="index.php">Medical E CARD :: A Govt. Project</a></span>
                        <span class="topbar-phone"><i class="fa fa-graduation-cap"></i> Done as Academic Project</span>
                    </div><!-- end callout -->
                </div><!-- end col -->
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="topbar_social pull-right">Welcome <?php echo $r_stf[2] ?></div><!-- end social icons -->
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end topbar -->
    
	<header class="header">
		<div class="container">
			<nav class="navbar yamm navbar-default">
				<div class="navbar-header">
                    <button type="button" data-toggle="collapse" data-target="#navbar-collapse-1" class="navbar-toggle">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                                    <a href="index.php" class="navbar-brand"><img src="../hospital/logo/<?php echo $r_hos[15] ?>" alt="<?php echo $r_hos[1] ?>" class="img img-responsive" style="height: 70px;"></a>
        		</div><!-- end navbar-header -->
                
				<div id="navbar-collapse-1" class="navbar-collapse collapse navbar-right">
					<ul class="nav navbar-nav">
                                            <li><a href="index.php">Home</a></li>
                                            <li class="active"><a href="patient.php">Admitted Patients</a></li>                                           
                                            <li><a href="../logout.php">Logout</a></li>
                        </ul><!-- end navbar-nav -->
				</div><!-- #navbar-collapse-1 -->
			</nav><!-- end navbar yamm navbar-default -->
		</div><!-- end container -->
    </header><!-- end header -->
	<div class="shadow"></div>

    	
    
	<div class="grey-wrapper">
    	<div class="container">
        	<div class="general_row">
            	<div class="big-title clearfix">
                	<h3>Admitted Patients</h3>
                </div><!-- end big title -->	
                
				<div class="custom_tab_2 row">                                    
                                    <div class="col-lg-8">
                                        <?php
                                        $sel_pat=mysql_query("select * from admit_entry where hid='$h_id' and st=0");
                                        if(mysql_num_rows($sel_pat)>0)
                                        {
                                            ?>
                                        <table class="table table-bordered table-condensed table-hover table-responsive table-striped">
                                            <tr>
                                                <td>#</td>
                                                <td>Patient Name</td>
                                                <td>Address</td>                                                
                                                <td>Disease & Doctor Observation</td>
                                                <td>ADD More</td>
                                            </tr>
                                            <?php
                                            $i=1;
                                            while($r_pat=mysql_fetch_row($sel_pat))
                                            {
                                                $sel_usr=mysql_query("select * from cit_data where bar_code='$r_pat[4]'");
                                                $r_usr=mysql_fetch_row($sel_usr);
                                                $sel_d1=mysql_query("select * from new_patient where id='$r_pat[3]'");
                                                $r_d1=mysql_fetch_row($sel_d1);
                                                ?>
                                            <tr>
                                                <td><?php echo $i ?></td>
                                                <td><strong><?php echo $r_usr[1] ?></strong><br />Temp :<?php echo $r_d1[6] ?><sup>o</sup>C<br />BP : <?php echo $r_d1[8] ?><br />Weight : <?php echo $r_d1[7] ?></td>
                                                <td><?php echo $r_usr[8] ?></td>
                                                <td><?php echo $r_d1[4] ?><br /><?php echo $r_d1[5] ?><br />Admitted On : <?php echo $r_d1[11] ?></td>
                                                <td><center>
                                                    <a href="patient.php?t=1&aid=<?php echo $r_pat[0] ?>"><span class="glyphicon glyphicon-star" style="color:green;" title="Medicine Provided"></span></a> | 
                                                    <a href="patient.php?t=2&aid=<?php echo $r_pat[0] ?>"><span class="glyphicon glyphicon-film" style="color:blue;" title="Test Reports"></span></a> | 
                                                    <a href="patient.php?t=3&aid=<?php echo $r_pat[0] ?>"><span class="glyphicon glyphicon-file" style="color:red;" title="Todays Status"></span></a> |
                                                    <a href="patient.php?dis=1&aid=<?php echo $r_pat[0] ?>&eid=<?php echo $r_pat[3] ?>"><span class="glyphicon glyphicon-log-out" style="color:orange;" title="Discharg"></span></a>
                                                            
                                            </center></td>
                                            </tr>
                                            <?php
                                                $i++;
                                            }
                                            ?>
                                        </table>
                                        <?php
                                        }
                                        else
                                        {
                                            ?>
                                        <div class="alert alert-danger">No Patient Data Found</div>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                    <div class="col-lg-4">
                                        <?php
                                        if(isset($_GET['t']))
                                        {
                                            $sel_admit=mysql_query("select * from admit_entry where id='".$_GET['aid']."'");
                                            $r_admit=mysql_fetch_row($sel_admit);
                                            $enq_id=$r_admit[3];
                                            $bar=$r_admit[4];
                                         if($_GET['t']=="1")
                                         {
                                             ?>
                                        <form method="post">
                                        <table class="table table-bordered table-condensed table-hover table-responsive table-striped">
                                            <tr>
                                                <td colspan="2"><center><STRONG>ADD MEDICINE</STRONG></center></td>
                                            </tr>
                                            <tr>
                                 <td>Department</td>
                                 <td><select name="dep1" class="form-control" onchange="loadmdcn(this.value)">
                                         <option>Choose</option>
                                         <?php
                                        $sel_dep=mysql_query("select * from department_data,hos_dep where department_data.id=hos_dep.dep_id and hos_dep.h_id='$h_id'");
                                        while($r_dep=mysql_fetch_row($sel_dep))
                                        {
                                            ?>
                                         <option value="<?php echo $r_dep[0] ?>"><?php echo $r_dep[1] ?></option>
                                         <?php
                                        }
                                        ?>
                                     </select></td>
                             </tr>
                             <script type="text/javascript">
                             function loadmdcn(x)
                             {
                                 var xmlhttp = new XMLHttpRequest();
                                    xmlhttp.onreadystatechange = function() {
                                        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {

                                            document.getElementById("mdcn1").innerHTML = xmlhttp.responseText;
                                        }
                                    };
                                    xmlhttp.open("GET", "get_medicin.php?d=" + x, true);
                                    xmlhttp.send();
                             }
                             </script>
                             <tr>
                                 <td>Medicine</td>
                                 <td><span id="mdcn1">
                                     <select name="mdcn" class="form-control">
                                         <option>Choose Medicine</option>
                                     </select></span>
                                 </td>
                             </tr>
                                            <tr>
                                                <td>Description</td>
                                                <td>
                                                    <input type="text" name="mds" class="form-control" required="required" placeholder="1-0-1" />
                                                    <input type="hidden" name="bar1" class="form-control" value="<?php echo $bar ?>" />
                                                    <input type="hidden" name="en1" class="form-control" value="<?php echo $enq_id ?>" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><center><input type="submit" name="add_mdc" value="ADD MEDICINE" class="btn-sm btn-success" /></center></td>
                                            </tr>
                                        </table>
                                            <?php
                                            $sel_md1=mysql_query("select distinct dt from admit_medicine where admit_id='".$_GET['aid']."' order by id desc");
                                            if(mysql_num_rows($sel_md1)>0)
                                            {
                                                ?>
                                            <table class="table table-bordered table-condensed table-hover table-responsive table-striped">
                                                <?php
                                                while($r_md1=mysql_fetch_row($sel_md1))
                                                {
                                                    ?>
                                                <tr>
                                                    <td colspan="4"><b><?php echo $r_md1[0] ?></b></td>                                                   
                                                </tr>
                                                <?php
                                                $sel_md2=mysql_query("select * from admit_medicine where admit_id='".$_GET['aid']."' and dt='$r_md1[0]'");
                                                if(mysql_num_rows($sel_md2)>0)
                                                {
                                                    $i=1;
                                                    while($r_md2=mysql_fetch_row($sel_md2))
                                                    {
                                                    ?>
                                                        <tr>
                                                            <td><?php echo $i ?></td>
                                                            <td><?php 
                                                            $sel_mdc1=mysql_query("select * from medicin_data where id='$r_md2[5]'");
                                                            $r_mdc1=mysql_fetch_row($sel_mdc1);
                                                            echo $r_mdc1[2] ?></td>
                                                            <td><?php echo $r_md2[6] ?></td>
                                                        </tr>
                                                <?php
                                                $i++;
                                                    }
                                                }
                                                }
                                                ?>                                                
                                            </table>
                                            <?php
                                            }
                                            ?>
                                            </form>
                                        <?php
                                         }
                                         if($_GET['t']=="2")
                                         {
                                             ?>
                                        <form method="post" enctype="multipart/form-data">
                                        <table class="table table-bordered table-condensed table-hover table-responsive table-striped">
                                            <tr>
                                                <td colspan="2"><center><STRONG>ADD LAB REPORTS</STRONG></center></td>
                                            </tr>
                                            <tr>                                 
                                                <td>Choose Test</td>
                                                <td>
                                                <select name="rtst" class="form-control">
                                                    <option>Choose Test</option>
                                                    <?php
                                                    $sel_lab=mysql_query("select * from labtest_data");
                                                    while($r_lab=mysql_fetch_row($sel_lab))
                                                    {
                                                        ?>
                                                    <option value="<?php echo $r_lab[0] ?>"><?php echo $r_lab[1] ?></option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Report</td>
                                                <td><input type="file" name="up" class="form-control" /></td>
                                            </tr>
                                            <tr>                                 
                                                <td>Type</td>
                                                <td>
                                                <select name="rtyp" class="form-control">
                                                    <option>Choose Report Type</option>
                                                    <option value="1">Image</option>
                                                    <option value="2">Audio</option>
                                                    <option value="3">Video</option>
                                                </select>
                                                    <input type="hidden" name="bar1" class="form-control" value="<?php echo $bar ?>" />
                                                    <input type="hidden" name="en1" class="form-control" value="<?php echo $enq_id ?>" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><center><input type="submit" name="add_rpt" value="ADD REPORT" class="btn-sm btn-success" /></center></td>
                                            </tr>
                                        </table>
                                            <?php
                                            $sel_md1=mysql_query("select distinct dt from admit_report where admit_id='".$_GET['aid']."' order by id desc");
                                            if(mysql_num_rows($sel_md1)>0)
                                            {
                                                ?>
                                            <table class="table table-bordered table-condensed table-hover table-responsive table-striped">
                                                <?php
                                                while($r_md1=mysql_fetch_row($sel_md1))
                                                {
                                                    ?>
                                                <tr>
                                                    <td colspan="4"><b><?php echo $r_md1[0] ?></b></td>                                                   
                                                </tr>
                                                <?php
                                                $sel_md2=mysql_query("select * from admit_report where admit_id='".$_GET['aid']."' and dt='$r_md1[0]'");
                                                if(mysql_num_rows($sel_md2)>0)
                                                {
                                                    $i=1;
                                                    while($r_md2=mysql_fetch_row($sel_md2))
                                                    {
                                                    ?>
                                                        <tr>
                                                            <td><?php echo $i ?></td>
                                                            <td><?php 
                                                            $sel_mdc1=mysql_query("select * from labtest_data where id='$r_md2[5]'");
                                                            $r_mdc1=mysql_fetch_row($sel_mdc1);
                                                            echo $r_mdc1[1] ?></td>
                                                            <td><a href="<?php echo "$r_md2[7]/$r_md2[6]" ?>" target="_blabk"><i class="glyphicon glyphicon-download"></i></a></td>
                                                        </tr>
                                                <?php
                                                $i++;
                                                    }
                                                }
                                                }
                                                ?>                                                
                                            </table>
                                            <?php
                                            }
                                            ?>
                                      </form>
                                        <?php
                                         }
                                         if($_GET['t']=="3")
                                         {
                                             ?>
                                        <form method="post">
                                        <table class="table table-bordered table-condensed table-hover table-responsive table-striped">
                                            <tr>
                                                <td colspan="2"><center><STRONG>ADD DOCTOR DESCRIPTION</STRONG></center></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><textarea name="ddsc" class="form-control"></textarea>
                                                <input type="hidden" name="bar1" class="form-control" value="<?php echo $bar ?>" />
                                                    <input type="hidden" name="en1" class="form-control" value="<?php echo $enq_id ?>" />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"><center><input type="submit" name="add_rvw" value="ADD REVIEW" class="btn-sm btn-success" /></center></td>
                                            </tr>
                                        </table>
                                            <?php
                                            $sel_md1=mysql_query("select distinct dr from admit_doc_des where admit_id='".$_GET['aid']."' order by id desc");
                                            if(mysql_num_rows($sel_md1)>0)
                                            {
                                                ?>
                                            <table class="table table-bordered table-condensed table-hover table-responsive table-striped">
                                                <?php
                                                while($r_md1=mysql_fetch_row($sel_md1))
                                                {
                                                    ?>
                                                <tr>
                                                    <td colspan="4"><b><?php echo $r_md1[0] ?></b></td>                                                   
                                                </tr>
                                                <?php
                                                $sel_md2=mysql_query("select * from admit_doc_des where admit_id='".$_GET['aid']."' and dr='$r_md1[0]'");
                                                if(mysql_num_rows($sel_md2)>0)
                                                {
                                                    $i=1;
                                                    while($r_md2=mysql_fetch_row($sel_md2))
                                                    {
                                                    ?>
                                                        <tr>
                                                            <td><?php echo $i ?></td>                                                          
                                                            <td><?php echo "$r_md2[5]" ?></td>
                                                        </tr>
                                                <?php
                                                $i++;
                                                    }
                                                }
                                                }
                                                ?>                                                
                                            </table>
                                            <?php
                                            }
                                            ?>
                                            </form>
                                        <?php
                                         }
                                        }                                        
                                        ?>
                                    </div>
                                                                                
                    
                    
				</div>
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end grey-wrapper -->
    
	
    
	
    
	
    
    
    
    <div class="copyright">
    	<div class="container">
        	<div class="row">
                <div class="col-lg-5 col-md-6 col-sm-12">
                    <div class="copyright-text">
                        <p>Copyright © 2016 - mEDICAL E cAED Designed by<br /> Trinity Technologies</p>
                    </div><!-- end copyright-text -->
                </div><!-- end widget -->
                <div class="col-lg-7 col-md-6 col-sm-12">
                    <div class="footer-menu">
                        
                    </div>
                </div><!-- end large-7 --> 
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end copyrights -->
    
	<div class="dmtop">Scroll to Top</div>
    
	<!-- Main Scripts-->
	<script src="../web_style/js/jquery.js"></script>
	<script src="../web_style/js/bootstrap.min.js"></script>
    <script src="../web_style/js/bootstrap-datetimepicker.js"></script>
	<script src="../web_style/js/menu.js"></script>
	<script src="../web_style/js/retina-1.1.0.js"></script>
	<script src="../web_style/js/custom.js"></script>

	<!-- CALENDAR WIDGET  -->
	<script type="text/javascript">
		(function($) {
		  "use strict";
			$('.form_datetime').datetimepicker({
				weekStart: 1,
				todayBtn:  1,
				autoclose: 1,
				todayHighlight: 1,
				startView: 2,
				forceParse: 0,
				showMeridian: 1
			});
		})(jQuery);
	</script>

	<!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
	<script type="text/javascript" src="../web_style/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
	<script type="text/javascript" src="../web_style/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
	<script type="text/javascript">
		(function($) {
		  "use strict";
			var revapi;
			jQuery(document).ready(function() {
				revapi = jQuery('.tp-banner').revolution(
				{
					delay:9000,
					startwidth:1170,
					startheight:560,
					hideThumbs:10,
					fullWidth:"on",
					forceFullWidth:"on"
				});
			});	//ready
		})(jQuery);
	</script>

	<!-- CAROUSEL WIDGET -->
	<script src="../web_style/js/owl.carousel.min.js"></script>
	<script>
		(function($) {
		  "use strict";
			// OWL Carousel
			$("#owl-blog").owlCarousel({
				items : 3,
				lazyLoad : true,
				navigation : true,
				pagination : false,
				autoPlay: false
			});
		})(jQuery);
	</script>
    
</body>

<!-- Mirrored from jollythemes.com/html/jollymedic/index1.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 05 Nov 2016 11:13:49 GMT -->
</html>